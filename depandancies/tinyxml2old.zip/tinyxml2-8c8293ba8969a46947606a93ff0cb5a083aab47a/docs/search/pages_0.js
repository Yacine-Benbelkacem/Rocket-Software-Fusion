var searchData=
[
  ['get_20information_20out_20of_20xml',['Get information out of XML',['../_example-3.html',1,'']]]
];
